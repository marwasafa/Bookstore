package com.example.ma_ass2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class bookauthorsbooks extends AppCompatActivity {
    EditText authorID;
    EditText isbn;
    String authID;
    String isbnNum;
    DBaseHelper db;
    Button addAuthorBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookauthorsbooks);
        addAuthorBook = (Button) findViewById(R.id.btnaddauthorbook);
        authorID = (EditText) findViewById(R.id.edittex1);
        isbn = (EditText) findViewById(R.id.edittex2);
        db = new DBaseHelper(this);

        addAuthorBook.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent iSave = new Intent(bookauthorsbooks.this, MainActivity.class);
                authID = authorID.getText().toString();
                isbnNum = isbn.getText().toString();
                int intAuthID = Integer.parseInt(authID);
                int intISBNNum = Integer.parseInt(isbnNum);
                addData(intAuthID, intISBNNum);
                iSave.putExtra("authorID", authID);
                iSave.putExtra("ISBN", isbnNum);
                startActivity(iSave);
                finish();
            }
        });

    }

    private void addData(int authID, int isbnNum) {
        boolean insert = db.addNewAuthorBook(authID, isbnNum);
        if(insert == true){
            Toast.makeText(this, "successfully entered", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(this, "unable to enter the author's name", Toast.LENGTH_LONG).show();
        }
    }
}