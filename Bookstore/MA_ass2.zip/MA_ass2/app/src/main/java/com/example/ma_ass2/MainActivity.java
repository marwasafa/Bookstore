package com.example.ma_ass2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DBaseHelper db;

    ListView authorList;
    ArrayList<String> authList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //authorList = (ListView) findViewById(R.id.authorList);
        db = new DBaseHelper(this);
//        authList = new ArrayList<String>();
//        Cursor data = db.getAuthorList();
//        if(data.getCount() == 0){
//            Toast.makeText(this, "database is empty", Toast.LENGTH_LONG).show();
//        }
//        else{
//            while(data.moveToNext()){
//                String fname = data.getString(1);
//                String lname = data.getString(2);
//                String fullname = fname + " " + lname;
//                authList.add(fullname);
//
//                ListAdapter listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, authList);
//                authorList.setAdapter(listAdapter);
//            }
//        }
    }


    public void onClickAddAuthor(View v){
        Intent addNewAuthor = new Intent(this, AddAuthor.class);
        startActivity(addNewAuthor);
    }

    public void onClickAddBookCategories(View view1){
        Intent bookcategories= new Intent(this, bookauthorsbooks.class);
        startActivity(bookcategories);
    }
    public void onClickAddBookCategoriesBook(View view1){
        Intent bookcategoriesbook = new Intent(this, bookauthorsbooks.class);
        startActivity(bookcategoriesbook);
    }
    public void onClickAddBookaruthorbooks(View view1){
        Intent bookAuthorsbook = new Intent(this, bookauthorsbooks.class);
        startActivity(bookAuthorsbook);
    }

}