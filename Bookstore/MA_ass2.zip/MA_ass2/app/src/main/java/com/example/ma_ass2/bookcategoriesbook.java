package com.example.ma_ass2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class bookcategoriesbook extends AppCompatActivity {

    EditText categoryID;
    EditText isbn;
    String catID;
    String isbnNum;
    DBaseHelper db;
    Button addCategoriesBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookcategories);
        categoryID = (EditText) findViewById(R.id.categoryid);
        isbn = (EditText) findViewById(R.id.categoryisbn);
        db = new DBaseHelper(this);

        addCategoriesBook.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent iSave = new Intent(bookcategoriesbook.this, MainActivity.class);
                catID = categoryID.getText().toString();
                isbnNum = isbn.getText().toString();
                int intcatID = Integer.parseInt(catID);
                int intisbnNum = Integer.parseInt(isbnNum);
                addData(intcatID, intisbnNum);
                iSave.putExtra("categoryID", intcatID);
                iSave.putExtra("ISBN", intisbnNum);
                startActivity(iSave);
                finish();
            }
        });

    }

    private void addData(int intcatID, int intisbnNum) {
        boolean insert = db.addNewBookCategoriesBook(intcatID, intisbnNum);
        if(insert == true){
            Toast.makeText(this, "successfully entered", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(this, "unable to enter the author's name", Toast.LENGTH_LONG).show();
        }
    }
}