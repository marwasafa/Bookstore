package com.example.ma_ass2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


import androidx.annotation.Nullable;

public class DBaseHelper extends SQLiteOpenHelper{

    public static final String DB_NAME = "bookstores.db";
    public static final int DB_VERSION = 4;
    public static final String TABLE_NAME = "authors";
    public static final String COL1 = "authorID";
    public static final String COL2 = "FirstName";
    public static final String COL3 = "LastName";

    public static final String TABLE2_NAME = "bookAuthorsBooks";
    public static final String COL_1 = "authorID";
    public static final String COL_2 = "ISBN";

    public static final String TABLE3_NAME = "bookCategories";
    public static final String TABLE4_NAME = "bookDescriptions";
    public static final String TABLE5_NAME = "bookCategoriesBooks";


    public DBaseHelper(@Nullable Context context) {
        super(context,DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if(!db.isReadOnly()){
            db.execSQL("PRAGMA foreign_keys=ON;");
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createBookCategoriesSQL = "CREATE TABLE "+ TABLE3_NAME + "( " +
                " categoryID Integer PRIMARY KEY, " +
                " categoryName Text NOT NULL) " +
                ";";
        Log.d("BookCategories",createBookCategoriesSQL);
        db.execSQL(createBookCategoriesSQL);

        String createBookDescriptionSQL = " CREATE TABLE " + TABLE4_NAME + "( " +
                " ISBN Integer PRIMARY KEY, " +
                " title  Text NOT NULL, " +
                " publisher  Text, " +
                " price  Integer, " +
                " quantity Integer, " +
                " edition Text, " +
                " pages Integer, " +
                " user Text)" +
                ";";
        db.execSQL(createBookDescriptionSQL);

        String createAuthorsSQL = "CREATE TABLE " + TABLE_NAME + "(" +
                COL1 + " Integer PRIMARY KEY AUTOINCREMENT," +
                COL2 +  " Text NOT NULL," +
                COL3 +  " Text NOT NULL)" + ";" ;
        Log.d("DBText","createTable: "+createAuthorsSQL);
        db.execSQL(createAuthorsSQL);

        String createBookAuthorBookSql = "CREATE TABLE " + TABLE2_NAME + "(" +
                COL_1 + " Integer NOT NULL," +
                COL_2 + " Integer NOT NULL," +
                " FOREIGN KEY (COL_1) REFERENCES authors (authorID),"+
                " FOREIGN KEY (COL_2) REFERENCES bookDescriptions (ISBN) )"+";" ;
        db.execSQL(createBookAuthorBookSql);

        String createBookCategoriesBooksSQL = " CREATE TABLE  "+TABLE5_NAME +"( " +
                "ISBN  Integer NOT NULL, " +
                "categoryID Integer NOT NULL, " +
                " CONSTRAINT PK_BookCategoriesBooks PRIMARY KEY (ISBN, categoryID), " +
                " FOREIGN KEY (ISBN) REFERENCES BookDecriptions(ISBN) ," +
                " FOREIGN KEY (categoryID) REFERENCES BookCategories (categoryID));";
        db.execSQL(createBookCategoriesBooksSQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE " + TABLE_NAME + ";");
        db.execSQL("DROP TABLE " + TABLE2_NAME + ";");
        db.execSQL("DROP TABLE " + TABLE3_NAME + ";");
        db.execSQL("DROP TABLE " + TABLE4_NAME + ";");
        db.execSQL("DROP TABLE " + TABLE5_NAME + ";");
        this.onCreate(db);

    }

    public boolean addNewAuthor(String firstName, String lastName){

        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2, firstName);
        contentValues.put(COL3, lastName);
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.insert(TABLE_NAME, null, contentValues);
        if(result == 0) return false;
        else return true;
    }

    public boolean addNewAuthorBook(int authorID, int isbn){
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1, authorID);
        contentValues.put(COL_2, isbn);
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.insert(TABLE2_NAME, null, contentValues);
        if(result == 0) return false;
        else return true;
    }

    public boolean addNewBookCategories(int categoryID, String categoryName){
        ContentValues contentValues = new ContentValues();
        contentValues.put("categoryID", categoryID);
        contentValues.put("categoryName", categoryName);
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.insert(TABLE3_NAME, null, contentValues);
        if(result == 0) return false;
        else return true;
    }

    public boolean addNewBookCategoriesBook(int categoryID, int isbn){
        ContentValues contentValues = new ContentValues();
        contentValues.put("categoryID", categoryID);
        contentValues.put("ISBN", isbn);
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.insert(TABLE5_NAME, null, contentValues);
        if(result == 0) return false;
        else return true;
    }
    public Cursor getAuthorList(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        return data;
    }

    public Cursor getAuthorBooks(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + TABLE2_NAME, null);
        return data;
    }
}
