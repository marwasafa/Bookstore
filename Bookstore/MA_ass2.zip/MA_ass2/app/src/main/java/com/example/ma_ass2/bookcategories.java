package com.example.ma_ass2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class bookcategories extends AppCompatActivity {

    EditText categoryID;
    EditText categoryName;
    String catID;
    String catName;
    DBaseHelper db;
    Button addCategories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookcategories);
        categoryID = (EditText) findViewById(R.id.categoryID);
        categoryName = (EditText) findViewById(R.id.categoryName);
        db = new DBaseHelper(this);

        addCategories.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent iSave = new Intent(bookcategories.this, MainActivity.class);
                catID = categoryID.getText().toString();
                catName = categoryName.getText().toString();
                int intcatID = Integer.parseInt(catID);

                addData(intcatID, catName);
                iSave.putExtra("categoryID", catID);
                iSave.putExtra("categoryName", catName);
                startActivity(iSave);
                finish();
            }
        });

    }

    private void addData(int intcatID, String catName) {
        boolean insert = db.addNewBookCategories(intcatID, catName);
        if(insert == true){
            Toast.makeText(this, "successfully entered", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(this, "unable to enter the author's name", Toast.LENGTH_LONG).show();
        }
    }
}