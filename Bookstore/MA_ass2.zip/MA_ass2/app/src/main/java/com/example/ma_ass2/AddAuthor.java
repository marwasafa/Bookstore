package com.example.ma_ass2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddAuthor extends AppCompatActivity {
    Button btnAddAuthor;
    EditText addAuthorFName;
    EditText addAuthorLName;
    String fname;
    String lname;
    DBaseHelper db;



    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_author);
        btnAddAuthor = (Button) findViewById(R.id.btnaddauthor);
        addAuthorFName = (EditText) findViewById(R.id.authorFName);
        addAuthorLName = (EditText) findViewById(R.id.authorLName);
        db = new DBaseHelper(this);

//        btnAddAuthor.setOnClickListener(new View.OnClickListener(){
//
//            @Override
//            public void onClick(View v) {
//                Intent iSave = new Intent(AddAuthor.this, MainActivity.class);
//                fname = addAuthorFName.getText().toString();
//                lname = addAuthorLName.getText().toString();
//                addData(fname, lname);
//                iSave.putExtra("firstname", fname);
//                iSave.putExtra("lastname", lname);
//                startActivity(iSave);
//                finish();
//            }
//        });
    }

    public void addData(String fname, String lname){
        boolean insert = db.addNewAuthor(fname, lname);
        if(insert == true){
            Toast.makeText(this, "successfully entered", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(this, "unable to enter the author's name", Toast.LENGTH_LONG).show();
        }

    }

//    public void onClickCancel(View v) {
//        Intent cancel = new Intent(this, MainActivity.class);
//        startActivity(cancel);
//    }
}
